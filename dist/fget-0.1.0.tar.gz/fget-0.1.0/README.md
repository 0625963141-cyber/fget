File Advanced Download Support HTTP and HTTPS and FTP protocol

fget
functionnality

Support HTTP Method POST/GET Support Proxy Authentication Support FTP Login and File Transfer Support FTP Anonymously Support IPV6 Support Force Https Support ignore CERT Expiration Suppport specific Time For WAIT AND Retry Connection For You Network has disconnected Support Custom Headers Support Custom USER Agent Support HTTP Authentication Support Custom Directory For Download file Support ALL File
Installation Instruction

all install is on INSTALL.md all requirements found on requirements.txt
END
ALL USAGE is on USAGE.md